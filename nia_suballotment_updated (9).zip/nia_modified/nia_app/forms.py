from django import forms
from .models import SubAllotmentAdvice, AllotmentStatement


class SubAllotmentAdviceForm(forms.ModelForm):
    class Meta:
        model = SubAllotmentAdvice
        exclude = ['created_at', 'updated_at']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Make all fields optional except advice_number
        for field_name, field in self.fields.items():
            if field_name != 'advice_number':
                field.required = False
        # Set default values
        if not self.instance.pk:
            self.fields['calendar_year'].initial = 2025
            self.fields['region'].initial = '13'
            self.fields['fund_code'].initial = '501'
            self.fields['to_office'].initial = 'REGIONAL IRRIGATION MANAGER'
            self.fields['total_amount'].initial = 0


class AllotmentStatementForm(forms.ModelForm):
    class Meta:
        model = AllotmentStatement
        fields = ['project_name', 'ada_number', 'allotment_received', 'date', 'remarks']
        widgets = {
            'project_name':       forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'e.g. Repair of Communal Irrigation Systems'}),
            'ada_number':         forms.TextInput(attrs={'class': 'form-input', 'placeholder': 'e.g. 501-2025-101-LFPs'}),
            'allotment_received': forms.NumberInput(attrs={'class': 'form-input', 'placeholder': '0.00', 'step': '0.01'}),
            'date':               forms.DateInput(attrs={'type': 'date', 'class': 'form-input'}),
            'remarks':            forms.Textarea(attrs={'class': 'form-input', 'rows': 3, 'placeholder': 'Optional remarks...'}),
        }
