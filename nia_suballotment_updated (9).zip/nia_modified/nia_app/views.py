import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import SubAllotmentAdvice, ProvinceAllotment, CISAllotment
from .forms import SubAllotmentAdviceForm


def index(request):
    advices = SubAllotmentAdvice.objects.prefetch_related('province_allotments__cis_allotments').all()
    return render(request, 'nia_app/index.html', {'advices': advices})


def create_advice(request):
    if request.method == 'POST':
        form = SubAllotmentAdviceForm(request.POST)
        try:
            provinces_data = json.loads(request.POST.get('provinces_data', '[]'))
        except json.JSONDecodeError:
            provinces_data = []

        if form.is_valid():
            advice = form.save(commit=False)
            # Get total_amount and words from POST (auto-calculated on frontend)
            total_str = request.POST.get('total_amount', '0').replace(',', '')
            try:
                advice.total_amount = float(total_str) if total_str else 0
            except ValueError:
                advice.total_amount = 0
            advice.amount_in_words = request.POST.get('amount_in_words', '')
            advice.save()
            for p_idx, prov in enumerate(provinces_data):
                prov_obj = ProvinceAllotment.objects.create(
                    sub_allotment=advice,
                    province_name=prov.get('name', ''),
                    province_total=prov.get('total', 0) or 0,
                    order=p_idx,
                )
                for c_idx, cis in enumerate(prov.get('cis_list', [])):
                    CISAllotment.objects.create(
                        province_allotment=prov_obj,
                        cis_name=cis.get('name', ''),
                        amount=cis.get('amount', 0) or 0,
                        order=c_idx,
                    )
            messages.success(request, f'Record "{advice.advice_number}" saved successfully!')
            return redirect('detail_advice', pk=advice.pk)
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = SubAllotmentAdviceForm()

    return render(request, 'nia_app/form.html', {
        'form': form, 'title': 'New Sub-Allotment Advice', 'action': 'Create',
    })


def detail_advice(request, pk):
    advice = get_object_or_404(
        SubAllotmentAdvice.objects.prefetch_related('province_allotments__cis_allotments'), pk=pk)
    return render(request, 'nia_app/detail.html', {'advice': advice})


def edit_advice(request, pk):
    advice = get_object_or_404(SubAllotmentAdvice, pk=pk)
    if request.method == 'POST':
        form = SubAllotmentAdviceForm(request.POST, instance=advice)
        try:
            provinces_data = json.loads(request.POST.get('provinces_data', '[]'))
        except json.JSONDecodeError:
            provinces_data = []

        if form.is_valid():
            advice = form.save()
            advice.province_allotments.all().delete()
            for p_idx, prov in enumerate(provinces_data):
                prov_obj = ProvinceAllotment.objects.create(
                    sub_allotment=advice,
                    province_name=prov.get('name', ''),
                    province_total=prov.get('total', 0) or 0,
                    order=p_idx,
                )
                for c_idx, cis in enumerate(prov.get('cis_list', [])):
                    CISAllotment.objects.create(
                        province_allotment=prov_obj,
                        cis_name=cis.get('name', ''),
                        amount=cis.get('amount', 0) or 0,
                        order=c_idx,
                    )
            messages.success(request, 'Record updated successfully!')
            return redirect('detail_advice', pk=advice.pk)
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = SubAllotmentAdviceForm(instance=advice)

    existing_provinces = [
        {
            'name': p.province_name,
            'total': float(p.province_total),
            'cis_list': [{'name': c.cis_name, 'amount': float(c.amount)} for c in p.cis_allotments.all()]
        }
        for p in advice.province_allotments.all()
    ]

    return render(request, 'nia_app/form.html', {
        'form': form,
        'title': f'Edit — {advice.advice_number}',
        'action': 'Update',
        'existing_provinces': json.dumps(existing_provinces),
        'advice': advice,
    })


def delete_advice(request, pk):
    advice = get_object_or_404(SubAllotmentAdvice, pk=pk)
    if request.method == 'POST':
        num = advice.advice_number
        advice.delete()
        messages.success(request, f'Record "{num}" deleted.')
        return redirect('index')
    return render(request, 'nia_app/confirm_delete.html', {'advice': advice})


# ─── Allotment Statement Views ────────────────────────────────────────────────
from .models import AllotmentStatement
from .forms import AllotmentStatementForm


def allotment_list(request):
    records = AllotmentStatement.objects.all()
    total = sum(r.allotment_received for r in records)
    return render(request, 'nia_app/allotment_list.html', {'records': records, 'total': total})


def allotment_create(request):
    if request.method == 'POST':
        form = AllotmentStatementForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Allotment record saved successfully!')
            return redirect('allotment_list')
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = AllotmentStatementForm()
    return render(request, 'nia_app/allotment_form.html', {'form': form, 'title': 'New Allotment Record', 'action': 'Create'})


def allotment_edit(request, pk):
    record = get_object_or_404(AllotmentStatement, pk=pk)
    if request.method == 'POST':
        form = AllotmentStatementForm(request.POST, instance=record)
        if form.is_valid():
            form.save()
            messages.success(request, 'Record updated successfully!')
            return redirect('allotment_list')
        else:
            messages.error(request, 'Please fix the errors below.')
    else:
        form = AllotmentStatementForm(instance=record)
    return render(request, 'nia_app/allotment_form.html', {'form': form, 'title': 'Edit Allotment Record', 'action': 'Update'})


def allotment_delete(request, pk):
    record = get_object_or_404(AllotmentStatement, pk=pk)
    if request.method == 'POST':
        record.delete()
        messages.success(request, 'Record deleted.')
        return redirect('allotment_list')
    return render(request, 'nia_app/allotment_confirm_delete.html', {'record': record})


# ── Master Table API Views ────────────────────────────────────────
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import GAASAROMaster, ObjectCodeMaster, DescriptionMaster, AdviceNumberMaster, CISMaster


def api_get_gaa(request):
    items = list(GAASAROMaster.objects.values_list('id', 'value'))
    return JsonResponse({'items': [{'id': i[0], 'value': i[1]} for i in items]})


def api_get_object_codes(request):
    items = list(ObjectCodeMaster.objects.values_list('id', 'value'))
    return JsonResponse({'items': [{'id': i[0], 'value': i[1]} for i in items]})


def api_get_descriptions(request):
    items = list(DescriptionMaster.objects.values_list('id', 'value'))
    return JsonResponse({'items': [{'id': i[0], 'value': i[1]} for i in items]})


def api_get_advice_numbers(request):
    items = list(AdviceNumberMaster.objects.values_list('id', 'value'))
    return JsonResponse({'items': [{'id': i[0], 'value': i[1]} for i in items]})


def api_get_cis(request):
    province = request.GET.get('province', '')
    all_flag = request.GET.get('all', '')
    if province:
        items = CISMaster.objects.filter(province=province).values('id', 'cis_name')
        return JsonResponse({'items': [{'id': i['id'], 'value': i['cis_name']} for i in items]})
    else:
        # Return all with province info for grouping
        items = CISMaster.objects.all().values('id', 'province', 'cis_name')
        return JsonResponse({'items': [{'id': i['id'], 'province': i['province'], 'cis_name': i['cis_name']} for i in items]})


@csrf_exempt
def api_save_item(request):
    """Save a new item to any master table."""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            table = data.get('table')
            value = data.get('value', '').strip()
            province = data.get('province', '').strip()

            if not value:
                return JsonResponse({'success': False, 'error': 'Value is required'})

            if table == 'gaa':
                obj, created = GAASAROMaster.objects.get_or_create(value=value)
            elif table == 'object_code':
                obj, created = ObjectCodeMaster.objects.get_or_create(value=value)
            elif table == 'description':
                obj, created = DescriptionMaster.objects.get_or_create(value=value)
            elif table == 'advice_number':
                obj, created = AdviceNumberMaster.objects.get_or_create(value=value)
            elif table == 'cis':
                if not province:
                    return JsonResponse({'success': False, 'error': 'Province is required for CIS'})
                obj, created = CISMaster.objects.get_or_create(province=province, cis_name=value)
            else:
                return JsonResponse({'success': False, 'error': 'Unknown table'})

            return JsonResponse({'success': True, 'id': obj.id, 'value': value, 'created': created})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'POST required'})


def master_lists(request):
    """Dedicated page for managing all master dropdown lists."""
    return render(request, 'nia_app/master_lists.html')


@csrf_exempt
def api_delete_item(request):
    """Delete an item from any master table."""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            table = data.get('table')
            item_id = data.get('id')

            if table == 'gaa':
                GAASAROMaster.objects.filter(id=item_id).delete()
            elif table == 'object_code':
                ObjectCodeMaster.objects.filter(id=item_id).delete()
            elif table == 'description':
                DescriptionMaster.objects.filter(id=item_id).delete()
            elif table == 'advice_number':
                AdviceNumberMaster.objects.filter(id=item_id).delete()
            elif table == 'cis':
                CISMaster.objects.filter(id=item_id).delete()

            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'POST required'})
